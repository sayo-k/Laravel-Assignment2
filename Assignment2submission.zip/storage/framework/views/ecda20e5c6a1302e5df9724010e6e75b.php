<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Are you ready to dance, <?php echo e($user->name); ?>? <br> You are our <?php echo e($user->role); ?>!!</h1>
    <h2>Your Courses:</h2>
    <ul class="list-group">
        <?php if($courses && $courses->isNotEmpty()): ?>
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <a href="<?php echo e(route('courses.show', $course->id)); ?>">
                        <?php echo e($course->course_code); ?> - <?php echo e($course->name); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <?php if($user->role == 'teacher'): ?>
                <p>You are not teaching any courses currently.</p>

            <?php elseif($user->role == 'student'): ?>
                <p>You are not enrolled in any courses currently.</p>
            <?php endif; ?>
        <?php endif; ?>

        <?php if($user->role == 'teacher'): ?>    
            <div class="container">
                <h4>Upload Course File</h4>

                <form action="<?php echo e(route('courses.upload')); ?>" method="POST" enctype="multipart/form-data" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="courseFile">Course Information File</label>
                        <input type="file" name="courseFile" id="courseFile" class="form-control" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Upload Course</button>
                </form>
            </div>
        <?php endif; ?>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/Assignment2/pr/resources/views/courses/index.blade.php ENDPATH**/ ?>