<?php $__env->startSection('content'); ?>
<div class="container">
    <h1><?php echo e($assessment->title); ?></h1>

    <div class="card">
        <div class="card-header">
            Instructions
        </div>
        <div class="card-body">
            <p><?php echo e($assessment->instruction); ?></p>
            <p><strong>Required Reviews:</strong> <?php echo e($assessment->required_reviews); ?></p>
            <p><strong>Due Date:</strong> <?php echo e(\Carbon\Carbon::parse($assessment->due_date)->format('Y-m-d H:i')); ?></p>
            <p><strong>Type:</strong> <?php echo e($assessment->type); ?></p>
        </div>
    </div><br>

    <?php if($assessment->type === 'student-select'): ?>
    <h2>Submit Peer Reviews</h2>
    <form action="<?php echo e(route('reviews.store', $assessment->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php for($i = 0; $i < $assessment->required_reviews; $i++): ?>
            <div id="reviews-container">
                <div class="form-group">
                    <label for="reviewee_id">Select Reviewee</label>
                    <!--[] in the name attribute >> both reviewee_id and review_text sent as arrays
                    form to handle multiple review submissions for different students.-->
                    <select name="reviewee_id[]" class="form-control" required>
                        <option value="">Select a student</option>
                        <?php $__currentLoopData = $enrolledStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($student->id); ?>"><?php echo e($student->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="review_text">Review Text</label>
                    <textarea name="review_text[]" class="form-control" required minlength="5"></textarea>
                </div>
            </div>
        <?php endfor; ?>
        <button type="submit" class="btn btn-primary mt-3">Submit Reviews</button>
    </form><br><br>
    <?php endif; ?>

    <?php if($assessment->type === 'teacher-assign'): ?>

        <?php if($submittedReviews->isNotEmpty()): ?>
        <form action="<?php echo e(route('reviews.update', $assessment->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <?php $__currentLoopData = $submittedReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submittedReview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="reviews-container">
                    <div class="form-group">
                        <label for="reviewee_id">Reviewing: <?php echo e($submittedReview->reviewee->name); ?></label>
                        <input type="hidden" name="reviewee_id[]" value="<?php echo e($submittedReview->reviewee->id); ?>">
                    </div>
                    <div class="form-group">
                        <label for="review_text">Review Text</label>
                        <textarea name="review_text[]" class="form-control" required minlength="5"></textarea>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <button type="submit" class="btn btn-primary mt-3">Submit Assigned Reviews</button>
        </form><br><br>
        <?php else: ?>
            <p>No reviews assigned to you yet.</p>
        <?php endif; ?>

    <?php endif; ?>

    <h3>Submitted Reviews</h3>
    <?php $__currentLoopData = $submittedReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="review">
            <p><strong>Reviewee:</strong> <?php echo e($review->reviewee->name); ?></p>
            <p><?php echo e($review->review_text); ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div> <br>

    <h2>Received Reviews</h2>
    <form action="<?php echo e(route('assessments.student_rate', $assessmentId)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $receivedReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="review">
                <p><strong>Reviewer:</strong> <?php echo e($review->reviewer->name); ?></p>
                <p><?php echo e($review->review_text); ?></p>
                <input type="hidden" name="reviewee_id[<?php echo e($review->id); ?>]" value="<?php echo e($revieweeId); ?>">
                
                <div class="form-group">
                    <label for="clarity_rating_<?php echo e($review->id); ?>">Clarity (1-5)</label>
                    <input type="number" name="clarity_rating[<?php echo e($review->id); ?>]" min="1" max="5" required>
                </div>
                <div class="form-group">
                    <label for="constructiveness_rating_<?php echo e($review->id); ?>">Constructiveness (1-5)</label>
                    <input type="number" name="constructiveness_rating[<?php echo e($review->id); ?>]" min="1" max="5" required>
                </div>
                <div class="form-group">
                    <label for="specificity_rating_<?php echo e($review->id); ?>">Specificity (1-5)</label>
                    <input type="number" name="specificity_rating[<?php echo e($review->id); ?>]" min="1" max="5" required>
                </div>
                <div class="form-group">
                    <label for="tone_rating_<?php echo e($review->id); ?>">Tone (1-5)</label>
                    <input type="number" name="tone_rating[<?php echo e($review->id); ?>]" min="1" max="5" required>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <button type="submit" class="btn btn-primary mt-3">Submit Review Ratings</button>
    </form>

    <div class="mt-3">
        <a href="<?php echo e(route('courses.show', $assessment->course_id)); ?>" class="btn btn-secondary">Back to Course</a>
        <a href="<?php echo e(route('reviews.top-reviewer', $reviewer->id)); ?>" class="btn btn-secondary">Check Top Reviewers</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/Assignment2/pr/resources/views/assessments/student_show.blade.php ENDPATH**/ ?>