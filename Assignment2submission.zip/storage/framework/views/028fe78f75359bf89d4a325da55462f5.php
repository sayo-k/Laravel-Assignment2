<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Assign Reviewers for Assessment: <?php echo e($assessment->title); ?></h1>

        <form action="<?php echo e(route('reviews.teacher-assign', $assessment->id)); ?>" method="POST" novalidate>
        <?php echo csrf_field(); ?>
        <h3>Groups of <?php echo e($assessment->required_reviews + 1); ?> students</h3>

        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupIndex => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h4>Group <?php echo e($groupIndex + 1); ?></h4>
            <ul>
                <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($student->name); ?>

                        <input type="hidden" name="groups[<?php echo e($groupIndex); ?>][]" value="<?php echo e($student->id); ?>">
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <button type="submit" class="btn btn-primary">Confirm Groups and Assign Reviews</button>
    </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/Assignment2/pr/resources/views/reviews/teacher-assign.blade.php ENDPATH**/ ?>