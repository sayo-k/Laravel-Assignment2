<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Reviews for <?php echo e($student->name); ?> - Assessment: <?php echo e($assessment->title); ?></h1>

        <?php if($reviews->isEmpty()): ?>
            <p>No reviews submitted by <?php echo e($student->name); ?> for this assessment.</p>
        <?php else: ?>
            <table class="table">
                <thead>
                <tr>
                    <th>Reviewer</th>
                    <th>Reviewee</th>
                    <th>Review Text</th>
                    <th>Date Submitted</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($review->reviewer->name); ?></td>  <!-- Reviewer's name -->
                        <td><?php echo e($review->reviewee->name); ?></td>  <!-- Reviewee's name -->
                        <td><?php echo e($review->review_text); ?></td>      <!-- Actual review text -->
                        <td><?php echo e($review->created_at->format('d M Y')); ?></td>  <!-- Date submitted -->
                    </tr>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>

        <?php if($reviewsReceived->isEmpty()): ?>
        <p>No reviews received by <?php echo e($student->name); ?> for this assessment.</p>
        <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Reviewer</th>
                    <th>Review Text</th>
                    <th>Date Submitted</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reviewsReceived; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($review->reviewer->name); ?></td>  <!-- Reviewer (who submitted the review) -->
                        <td><?php echo e($review->review_text); ?></td>    <!-- Actual review text -->
                        <td><?php echo e($review->created_at->format('d M Y')); ?></td>  <!-- Date submitted -->
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
    </div>

    <h2>Enrolled Students - Score Update</h2>
    <table class="table">
            <thead>
            <tr>
                <th>Student Name</th>
                <th>Score</th>
                <th>Update Score</th>
                </tr>
            </thead>
            <tbody>

        <tr>
            <td><?php echo e($student->name); ?></td>
            <td><?php echo e($student->getScoreForAssessment($assessment->id)); ?></td>
            <td>
                <form action="<?php echo e(route('scores.update', [$assessment->id, $student->id])); ?>" method="POST" novalidate>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="number" name="score" value="<?php echo e($student->score); ?>" min="0" max="<?php echo e($assessment->max_score); ?>" required> 
                    <button type="submit" class="btn btn-success btn-sm">Update Score</button>
                </form>
            </td>
            
        </tr>
    </table>
        <td>
            <a href="<?php echo e(route('assessments.teacher_show', $assessment->id)); ?>" class="btn btn-info btn-sm">Back to Assessment</a>
        </td>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/Assignment2/pr/resources/views/reviews/show.blade.php ENDPATH**/ ?>