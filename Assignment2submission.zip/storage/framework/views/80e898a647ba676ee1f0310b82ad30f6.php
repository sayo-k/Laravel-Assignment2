<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__currentLoopData = $topReviewers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reviewer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <h3><?php echo e($reviewer->name); ?> - RIS: <?php echo e(number_format($reviewer->ris, 2)); ?></h3>
            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/Assignment2/pr/resources/views/reviews/top-reviewer.blade.php ENDPATH**/ ?>