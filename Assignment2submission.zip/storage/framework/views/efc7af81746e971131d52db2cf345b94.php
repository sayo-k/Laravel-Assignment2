<?php $__env->startSection('title', 'Course Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1><?php echo e($course->name); ?></h1>
        <p><strong>course_code: </strong><?php echo e($course->course_code); ?></p>
        <p><strong>Instructors: </strong><?php echo e($course->teacher->name); ?></p>

        <h2>Peer Review Assessments</h2>
        <ul>
            <?php $__currentLoopData = $course->assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php if(auth()->user()->isTeacher()): ?>
                        <a href="<?php echo e(route('assessments.teacher_show', $assessment->id)); ?>"><?php echo e($assessment->title); ?></a>
                    <?php else: ?>
                        <a href="<?php echo e(route('assessments.student_show', $assessment->id)); ?>"><?php echo e($assessment->title); ?></a>
                    <?php endif; ?>
                    - Due: <?php echo e(\Carbon\Carbon::parse($assessment->due_date)->format('M d, Y')); ?><br><br>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($user->role === 'teacher'): ?>
                <form action="<?php echo e(route('courses.enroll', $courseId)); ?>" method="POST" novalidate>
                    <?php echo csrf_field(); ?>

                    <h4>Add Studetns to Enroll</h4>
                    <select name="student_id">
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($student->id); ?>"><?php echo e($student->name); ?> (<?php echo e($student->s_number); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select><br><br>
                    <button type="submit">Enroll Student</button>
                </form><br><br>
                

                <h4>Add Peer Review Assessment</h4>
                <form action="<?php echo e(route('assessments.store')); ?>" method="POST" novalidate>
                <!--<form action="<?php echo e(route('assessments.store', $courseId)); ?>" method="POST">-->
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>" required>
                    <label for="title">Assessment Title (max 20 characters):</label><br>
                    <input type="text" name="title" maxlength="20" required><br>

                    <label for="instruction">Instruction:</label><br>
                    <textarea name="instruction" required></textarea><br>

                    <label for="required_reviews">Number of Reviews Required:</label><br>
                    <input type="number" name="required_reviews" min="1" required><br>

                    <label for="max_score">Maximum Score:</label><br>
                    <input type="number" name="max_score" min="1" max="100" required><br>

                    <label for="due_date">Due Date and Time:</label><br>
                    <input type="datetime-local" name="due_date" required><br>

                    <label for="type">Review Type:</label><br>
                    <select name="type" required><br>
                        <option value="student-select">Student-Select</option>
                        <option value="teacher-assign">Teacher-Assign</option>
                    </select><br><br>

                    <button type="submit">Add Assessment</button>
                </form>
            <?php endif; ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/Assignment2/pr/resources/views/courses/show.blade.php ENDPATH**/ ?>