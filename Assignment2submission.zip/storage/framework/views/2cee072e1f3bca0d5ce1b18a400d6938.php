<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Assessment Details</h1>

    <div class="card">
        <div class="card-header">
            <?php echo e($assessment->title); ?>

        </div>
        <div class="card-body">
            <h5 class="card-title">Instructions</h5>
            <p class="card-text"><?php echo e($assessment->instruction); ?></p>

            <h5 class="card-title">Details</h5>
            <p class="card-text"><strong>Required Reviews:</strong> <?php echo e($assessment->required_reviews); ?></p>
            <p class="card-text"><strong>Max Score:</strong> <?php echo e($assessment->max_score); ?></p>
            <p class="card-text"><strong>Due Date:</strong> <?php echo e(\Carbon\Carbon::parse($assessment->due_date)->format('Y-m-d H:i')); ?></p>
            <p class="card-text"><strong>Type:</strong> <?php echo e($assessment->type); ?></p>
        </div>
    </div>

    <a href="<?php echo e(route('assessments.edit', $assessment->id)); ?>" class="btn btn-primary mt-3">Edit Assessment</a>
    <a href="<?php echo e(route('courses.show', $assessment->course_id)); ?>" class="btn btn-secondary mt-3">Back to Course</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/Assignment2/pr/resources/views/assessments/show.blade.php ENDPATH**/ ?>