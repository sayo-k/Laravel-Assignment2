<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Assessment: <?php echo e($assessment->title); ?></h1><br><br>
        <h2>Edit Assessment</h2>

        <form action="<?php echo e(route('assessments.update', $assessment->id)); ?>" method="POST" novalidate>
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>

            <div class="form-group">
                <label for="title">Title</label>
                <input type="text" name="title" id="title" value="<?php echo e(old('title', $assessment->title)); ?>" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="instruction">Instruction</label>
                <textarea name="instruction" id="instruction" class="form-control" required><?php echo e(old('instruction', $assessment->instruction)); ?></textarea>
            </div>

            <div class="form-group">
                <label for="required_reviews">Required Reviews</label>
                <input type="number" name="required_reviews" id="required_reviews" value="<?php echo e(old('required_reviews', $assessment->required_reviews)); ?>" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="max_score">Max Score</label>
                <input type="number" name="max_score" id="max_score" value="<?php echo e(old('max_score', $assessment->max_score)); ?>" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="due_date">Due Date</label>
                <input type="datetime-local" name="due_date" id="due_date" value="<?php echo e(old('due_date', \Carbon\Carbon::parse($assessment->due_date)->format('Y-m-d\TH:i'))); ?>" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="type">Type</label>
                <select name="type" id="type" class="form-control" required>
                    <option value="student-select" <?php echo e($assessment->type == 'student-select' ? 'selected' : ''); ?>>Student Select</option>
                    <option value="teacher-assign" <?php echo e($assessment->type == 'teacher-assign' ? 'selected' : ''); ?>>Teacher Assign</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Update Assessment</button><br><br>
            <a href="<?php echo e(route('courses.show', $assessment->course_id)); ?>" class="btn btn-secondary mt-3">Back to Course</a><br><br>
            <?php if($assessment->type == 'teacher-assign'): ?>
                <a href="<?php echo e(route('reviews.teacher-assign', $assessment->course_id)); ?>" class="btn btn-secondary mt-3">Assign Reviews</a>
            <?php endif; ?>
        </form><br><br>
    </div>

    <h2>Student Review Summary</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Student Name</th>
                <th>Reviews Submitted</th>
                <th>Reviews Received</th>
                <th>Score</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $enrolledStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($student->name); ?></td>
                <td><?php echo e($student->submittedReviewsCount); ?></td>
                <td><?php echo e($student->receivedReviewsCount); ?></td>
                <td><?php echo e($student->getScoreForAssessment($assessment->id)); ?></td>
                <td>
                    <a href="<?php echo e(route('students.reviews', [$assessment->id, $student->id])); ?>" class="btn btn-info btn-sm">View Reviews</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
    <!--Laravel's Built-in Pagination-->
    
    <div class="pagination mt-4">
        <?php echo e($enrolledStudents->links()); ?> 
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/Assignment2/pr/resources/views/assessments/teacher_show.blade.php ENDPATH**/ ?>